def chi_mode(delta_chi=0):
    """返回1.03±0.02 kHz频率（单位Hz）"""
    return 1030 * (1 + 0.02 * delta_chi)

if __name__ == "__main__":
    freq = chi_mode()
    print(f"χ-mode frequency: {freq:.2f} Hz")
